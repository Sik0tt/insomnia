<template>
  <div class="home">
    Home
  </div>
</template>

<script>
export default {
  name: "home"
};
</script>
