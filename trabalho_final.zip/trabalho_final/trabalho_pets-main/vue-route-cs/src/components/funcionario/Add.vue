<template>
    <div class="submit-form">
      <div v-if="!submitted">       

        <div class="form-group">
            <label for="inputCpf">Cpf:</label>
            <input type="text" v-model="funcionario.cpf" class="form-control" id="inputCpf">
        </div>

        <div class = "form-group">
        <label for="inputRg">Rg:</label>
            <input type="text" v-model="funcionario.rg" class="form-control" id="inputRg">
        </div>

        <div class = "form-group">
        <label for="inputNome">Nome:</label>
            <input type="text" v-model="funcionario.nome" class="form-control" id="inputNome">
        </div>

         <div class = "form-group">
        <label for="inputNome">Numero_celular:</label>
            <input type="text" v-model="funcionario.Numero_celular" class="form-control" id="inputNumero_celular">
        </div>

         <div class = "form-group">
        <label for="inputNome">Email:</label>
            <input type="text" v-model="funcionario.email" class="form-control" id="inputEmail">
        </div>

         <div class = "form-group">
        <label for="inputNome">Data_nascimento:</label>
            <input type="text" v-model="funcionario.data_nascimento" class="form-control" id="inputDataNascimento">
        </div>

         <div class = "form-group">
        <label for="inputNome">Endereço:</label>
            <input type="text" v-model="funcionario.endereco" class="form-control" id="inputEndereco">
        </div>

         <div class = "form-group">
        <label for="inputNome">Cep</label>
            <input type="text" v-model="funcionario.cep" class="form-control" id="inputCep">
        </div>

         <div class = "form-group">
        <label for="inputNome">Complemento:</label>
            <input type="text" v-model="funcionario.nome" class="form-control" id="inputNome">
        </div>

         <div class = "form-group">
        <label for="inputNome">Ctps:</label>
            <input type="text" v-model="funcionario.ctps" class="form-control" id="inputCtps">
        </div>

         <div class = "form-group">
        <label for="inputNome">Pis:</label>
            <input type="text" v-model="funcionario.pis" class="form-control" id="inputPis">
        </div>

        <div class="form-group">
            <label for="inputSenha">Senha:</label>
            <input type="password" v-model="funcionario.senha" class="form-control" id="inputSenha">
        </div>            


            
          
  
        <button @click="saveFuncionarios" class="btn btn-success">Salvar</button>
        <router-link to="/funcionarios" class="btn btn-success">Voltar</router-link>                

      </div>
  
      <div v-else>
        <h4>Dados enviados com sucesso !</h4>
        <button class="btn btn-success" @click="newFuncionario">Novo</button>
        <router-link to="/funcionarios" class="btn btn-success">Voltar</router-link>
      </div>
    </div>
  </template>

<script>

    import JogadorDataService from '../../services/JogadorDataService'
    import PatenteDataService from '../../services/PatenteDataService'

    export default {
        name: "addJogador",
        data(){
            return {
                jogador: {indice: '', 
                                    nickname: '', 
                                    senha: '',
                                    pontos: 0, 
                                    quantdinheiro: 0,                                                                        
                                    situacao: true,  
                                    endereco: {codigo: 0, cep: '', complemento: ''},
                                    patentes: []},
                submitted: false,
                patentes: []
            }            
        },
        methods: {

            saveJogador(){

                var jgd = jQuery.extend({}, this.jogador);//clona o this.novo_jogador e armazena na variavel jogador. dessa forma alteracoes em this.novo_jogador nao irao refletir em jogador.
                var end = jQuery.extend({}, this.jogador.endereco);//clona o this.novo_jogador.endereco                        
                jgd.endereco = end;                                                

                if (jgd.nickname.trim().length > 0 && jgd.senha.trim().length > 0 && 
                        jgd.quantpontos > -1 && jgd.quantdinheiro > -1 && 
                        jgd.endereco.cep.length > 0) {
                
                    JogadorDataService.create(jgd)
                    .then(response => {
                        
                        this.submitted = true;
                    })
                    .catch(e => {                        
                        alert("Erro ao tentar cadastrar. !!! " + e.message);

                    })

                }else{
                    alert('Formulário incompleto !!!');
                }

            },
            newJogador(){

                this.submitted = false;
                this.jogador = {};
            },
            listPatentes(){

                PatenteDataService.list().then(response =>{

                console.log("Retorno do seviço PatenteDataService.list", response.status);

                for(let j of response.data){

                    this.patentes.push(j);
                }                  

                }).catch(response => {

                // error callback
                alert('Não conectou no serviço PatenteDataService.list');
                console.log(response);
                });               
            }

        },
        mounted() {                        
            this.listPatentes();
            
         }

    }

</script>

<style>
.submit-form {
  max-width: 300px;
  margin: auto;
}
</style>