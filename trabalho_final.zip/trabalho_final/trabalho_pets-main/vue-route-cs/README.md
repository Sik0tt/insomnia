# vuejs_router_componets_cs

> utilizacao de componentes para a interface grafica do estudo de caso: CS

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report


documentacao:
https://www.freecodecamp.org/news/how-to-use-routing-in-vue-js-to-create-a-better-user-experience-98d225bbcdd9/
https://github.com/hayanisaid/Vue-router
https://v2.vuejs.org/v2/guide/routing.html
https://www.bezkoder.com/vue-js-crud-app/
https://programandosolucoes.dev.br/2021/09/14/login-com-vuejs/


https://vuejs.org/guide/essentials/component-basics.html
```



For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
